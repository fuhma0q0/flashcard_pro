# FlashcardPRO

FlashcardPRO is a flashcard creation and learning application built with Django and React.

## Features

- Create flashcards with questions and answers
- View and delete flashcards
- REST API for managing flashcards

## Installation

1. Clone the repository:

```sh
git clone https://github.com/fuhma0q0/flashcardpro.git
cd flashcardpro
